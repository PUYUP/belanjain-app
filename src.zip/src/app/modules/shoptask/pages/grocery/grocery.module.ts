import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GroceryPage } from './grocery.page';

import { SharedModule } from '../../../../utils/shared.module';
import { GroceryPageRoutingModule } from './grocery-routing.module';
import { GroceryListComponent } from '../../components/grocery-list/grocery-list.component';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    GroceryPageRoutingModule,
    SharedModule
  ],
  declarations: [
    GroceryPage,
    //GroceryListComponent
  ],
  entryComponents: [
    //GroceryListComponent
  ]
})
export class GroceryPageModule {}
