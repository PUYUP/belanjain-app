import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SharedModule } from '../../../../utils/shared.module';
import { GroceryDetailPageRoutingModule } from './grocery-detail-routing.module';
import { GroceryDetailPage } from './grocery-detail.page';
import { NecessaryListComponent } from '../../components/necessary-list/necessary-list.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GroceryDetailPageRoutingModule,
    SharedModule
  ],
  declarations: [
    GroceryDetailPage,
    NecessaryListComponent
  ],
  entryComponents: [
    NecessaryListComponent
  ]
})
export class GroceryDetailPageModule {}
