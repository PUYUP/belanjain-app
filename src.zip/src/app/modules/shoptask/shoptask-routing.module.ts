import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'grocery',
    children: [
      {
        path: ':purchase_uuid',
        children: [
          {
            path: '',
            loadChildren: () => import('./pages/grocery-detail/grocery-detail.module').then(m => m.GroceryDetailPageModule)
          },
          {
            path: 'necessary',
            children: [
              {
                path: ':necessary_uuid',
                children: [
                  {
                    path: 'goods',
                    children: [
                      {
                        path: '',
                        loadChildren: () => import('./pages/goods/goods.module').then( m => m.GoodsPageModule)
                      },
                      {
                        path: 'catalog',
                        loadChildren: () => import('./pages/catalog/catalog.module').then( m => m.CatalogPageModule)
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        path: '',
        redirectTo: '/tabs/grocery',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ShoptaskRoutingModule {}
