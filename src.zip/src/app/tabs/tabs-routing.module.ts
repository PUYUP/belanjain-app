import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';
import { LoginRequiredGuard } from '../guards/login-required.guard';
import { GroceryPage } from '../modules/shoptask/pages/grocery/grocery.page';
import { HistoryPage } from '../modules/shoptask/pages/history/history.page';
import { AccountPage } from '../modules/person/pages/account/account.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'grocery',
        canActivate: [LoginRequiredGuard],
        component: GroceryPage,
        // loadChildren: () => import('../modules/shoptask/pages/grocery/grocery.module').then(m => m.GroceryPageModule)
      },
      {
        path: 'history',
        canActivate: [LoginRequiredGuard],
        component: HistoryPage,
        // loadChildren: () => import('../modules/shoptask/pages/history/history.module').then(m => m.HistoryPageModule)
      },
      {
        path: 'account',
        canActivate: [LoginRequiredGuard],
        component: AccountPage,
        // loadChildren: () => import('../modules/person/pages/account/account.module').then(m => m.AccountPageModule)
      },
      {
        path: '',
        redirectTo: '/tabs/grocery',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/grocery',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}
