import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';

import { PurchaseEditorComponent } from '../modules/shoptask/components/purchase-editor/purchase-editor.component';
import { NecessaryEditorComponent } from '../modules/shoptask/components/necessary-editor/necessary-editor.component';
import { GroceryListComponent } from '../modules/shoptask/components/grocery-list/grocery-list.component';

@NgModule({ 
    imports: [
        IonicModule,
        CommonModule,
        RouterModule,
        FormsModule,
        ReactiveFormsModule
    ],
    exports: [
        FormsModule,
        ReactiveFormsModule,
        PurchaseEditorComponent,
        NecessaryEditorComponent,
        GroceryListComponent
    ],
    declarations: [
        PurchaseEditorComponent,
        NecessaryEditorComponent,
        GroceryListComponent
    ],
    entryComponents: [
        PurchaseEditorComponent,
        NecessaryEditorComponent,
        GroceryListComponent
    ]
})
export class SharedModule {}